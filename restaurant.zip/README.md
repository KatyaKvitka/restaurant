# Angular 7 Developer Portfolio Web App [Part 1]

Read the tutorial for more information how to build this demo: [Angular 7 Course: Modules, CRUD, Routing & Bootstrap 4](https://www.techiediaries.com/angular-course/)

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.1.4.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

